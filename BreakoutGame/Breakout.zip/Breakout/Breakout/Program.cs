﻿
using var game = new Breakout.Game1();
game.Run();
